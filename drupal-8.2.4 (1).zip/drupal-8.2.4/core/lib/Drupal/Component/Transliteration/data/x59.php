<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => 'shou', 'yi', 'zhi', 'gu', 'chu', 'jiang', 'feng', 'bei', 'zhai', 'bian', 'sui', 'qun', 'ling', 'fu', 'cuo', 'xia',
  0x10 => 'xiong', 'xie', 'nao', 'xia', 'kui', 'xi', 'wai', 'yuan', 'mao', 'su', 'duo', 'duo', 'ye', 'qing', 'wai', 'gou',
  0x20 => 'gou', 'qi', 'meng', 'meng', 'yin', 'huo', 'chen', 'da', 'ze', 'tian', 'tai', 'fu', 'guai', 'yao', 'yang', 'hang',
  0x30 => 'gao', 'shi', 'tao', 'tai', 'tou', 'yan', 'bi', 'yi', 'kua', 'jia', 'duo', 'hua', 'kuang', 'yun', 'jia', 'ba',
  0x40 => 'en', 'lian', 'huan', 'di', 'yan', 'pao', 'juan', 'qi', 'nai', 'feng', 'xie', 'fen', 'dian', 'yang', 'kui', 'zou',
  0x50 => 'huan', 'qi', 'kai', 'zha', 'ben', 'yi', 'jiang', 'tao', 'zang', 'ben', 'xi', 'huang', 'fei', 'diao', 'xun', 'beng',
  0x60 => 'dian', 'ao', 'she', 'weng', 'ha', 'ao', 'wu', 'ao', 'jiang', 'lian', 'duo', 'yun', 'jiang', 'shi', 'fen', 'huo',
  0x70 => 'bi', 'luan', 'duo', 'nu', 'nu', 'ding', 'nai', 'qian', 'jian', 'ta', 'jiu', 'nuan', 'cha', 'hao', 'xian', 'fan',
  0x80 => 'ji', 'shuo', 'ru', 'fei', 'wang', 'hong', 'zhuang', 'fu', 'ma', 'dan', 'ren', 'fu', 'jing', 'yan', 'hai', 'wen',
  0x90 => 'zhong', 'pa', 'du', 'ji', 'keng', 'zhong', 'yao', 'jin', 'yun', 'miao', 'fou', 'chi', 'yue', 'zhuang', 'niu', 'yan',
  0xA0 => 'na', 'xin', 'fen', 'bi', 'yu', 'tuo', 'feng', 'wan', 'fang', 'wu', 'yu', 'gui', 'du', 'ba', 'ni', 'zhou',
  0xB0 => 'zhuo', 'zhao', 'da', 'nai', 'yuan', 'tou', 'xian', 'zhi', 'e', 'mei', 'mo', 'qi', 'bi', 'shen', 'qie', 'e',
  0xC0 => 'he', 'xu', 'fa', 'zheng', 'min', 'ban', 'mu', 'fu', 'ling', 'zi', 'zi', 'shi', 'ran', 'shan', 'yang', 'man',
  0xD0 => 'jie', 'gu', 'si', 'xing', 'wei', 'zi', 'ju', 'shan', 'pin', 'ren', 'yao', 'dong', 'jiang', 'shu', 'ji', 'gai',
  0xE0 => 'xiang', 'hua', 'juan', 'jiao', 'gou', 'lao', 'jian', 'jian', 'yi', 'nian', 'zhi', 'ji', 'ji', 'xian', 'heng', 'guang',
  0xF0 => 'jun', 'kua', 'yan', 'ming', 'lie', 'pei', 'e', 'you', 'yan', 'cha', 'shen', 'yin', 'shi', 'gui', 'quan', 'zi',
);
